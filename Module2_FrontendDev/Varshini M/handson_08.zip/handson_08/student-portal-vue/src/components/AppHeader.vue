<template>
  <header class="header">
    <h1>Student Portal</h1>

    <nav>
      <RouterLink to="/">Home</RouterLink>

      <RouterLink to="/courses">Courses</RouterLink>

      <RouterLink to="/profile">Profile</RouterLink>
    </nav>

    <p>
      Enrolled Courses:
      <strong>{{ store.enrolledCourses.length }}</strong>
    </p>
  </header>
</template>

<script setup>
import { RouterLink } from 'vue-router'
import { useEnrollmentStore } from '@/stores/enrollment'

const store = useEnrollmentStore()
</script>

<style scoped>
.header {
  background: #1976d2;
  color: white;
  padding: 20px;
}

nav {
  margin: 10px 0;
}

nav a {
  color: white;
  margin-right: 20px;
  text-decoration: none;
}

nav a.router-link-active {
  font-weight: bold;
  text-decoration: underline;
}
</style>
