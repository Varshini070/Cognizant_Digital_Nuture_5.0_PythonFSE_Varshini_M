<script setup>
const emit = defineEmits(['enroll'])
</script>

<template>
  <div class="card">
    <h3>{{ name }}</h3>
    <p>{{ code }}</p>
    <p>Credits: {{ credits }}</p>
    <p>Grade: {{ grade }}</p>

    <button @click="emit('enroll')">Enroll</button>
  </div>
</template>

<style scoped>
.course-card {
  border: 1px solid #ccc;
  border-radius: 10px;
  padding: 20px;
  background: white;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
}

button {
  margin-top: 15px;
  padding: 8px 16px;
  background: #3498db;
  color: white;
  border: none;
  cursor: pointer;
}

button:hover {
  background: #2980b9;
}
</style>
