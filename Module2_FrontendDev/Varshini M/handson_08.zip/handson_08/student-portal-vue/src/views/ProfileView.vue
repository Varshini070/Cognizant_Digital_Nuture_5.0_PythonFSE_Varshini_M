<template>
  <div>
    <h2>Student Profile</h2>

    <h3>Enrolled Courses</h3>

    <div v-if="store.enrolledCourses.length === 0">No courses enrolled.</div>

    <div v-for="course in store.enrolledCourses" :key="course.id" class="course">
      <h4>{{ course.name }}</h4>

      <p>{{ course.code }}</p>

      <p>Credits: {{ course.credits }}</p>

      <button @click="store.unenroll(course.id)">Remove</button>
    </div>

    <hr />

    <h3>Total Credits: {{ store.totalCredits }}</h3>
  </div>
</template>

<script setup>
import { useEnrollmentStore } from '@/stores/enrollment'

const store = useEnrollmentStore()
</script>

<style scoped>
.course {
  border: 1px solid #ccc;
  padding: 15px;
  margin: 10px 0;
  border-radius: 8px;
}

button {
  margin-top: 10px;
  padding: 8px 12px;
}
</style>
