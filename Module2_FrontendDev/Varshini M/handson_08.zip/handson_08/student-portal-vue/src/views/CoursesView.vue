<template>
  <div v-for="course in filteredCourses" :key="course.id" class="course-item">
    <CourseCard
      v-for="course in filteredCourses"
      :key="course.id"
      :name="course.name"
      :code="course.code"
      :credits="course.credits"
      :grade="course.grade"
      @enroll="enroll(course)"
    />

    <button @click="enroll(course)">Enroll</button>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

import CourseCard from '@/components/CourseCard.vue'

import { useEnrollmentStore } from '@/stores/enrollment'

const store = useEnrollmentStore()

const searchTerm = ref('')

const courses = ref([])

onMounted(() => {
  courses.value = [
    {
      id: 1,
      name: 'Web Development',
      code: 'CS101',
      credits: 4,
      grade: 'A',
    },
    {
      id: 2,
      name: 'Database Systems',
      code: 'CS102',
      credits: 3,
      grade: 'A',
    },
    {
      id: 3,
      name: 'Operating Systems',
      code: 'CS103',
      credits: 4,
      grade: 'B+',
    },
    {
      id: 4,
      name: 'Computer Networks',
      code: 'CS104',
      credits: 3,
      grade: 'A',
    },
    {
      id: 5,
      name: 'Machine Learning',
      code: 'CS105',
      credits: 4,
      grade: 'A+',
    },
  ]
})

const filteredCourses = computed(() =>
  courses.value.filter((course) =>
    course.name.toLowerCase().includes(searchTerm.value.toLowerCase()),
  ),
)

function enroll(course) {
  store.enroll(course)
  alert(`${course.name} enrolled successfully!`)
}
</script>

<style scoped>
input {
  padding: 8px;
  margin: 15px 0;
  width: 250px;
}

button {
  margin: 5px;
  padding: 8px 12px;
}
</style>
