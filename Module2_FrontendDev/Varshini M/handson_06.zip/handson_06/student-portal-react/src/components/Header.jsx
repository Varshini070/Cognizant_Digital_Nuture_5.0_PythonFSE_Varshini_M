import { Link } from "react-router-dom";

import { useSelector } from "react-redux";

function Header() {
  const enrolledCourses = useSelector(
    (state) => state.enrollment.enrolledCourses,
  );

  return (
    <header>
      <nav className="container">
        <h1>Student Portal</h1>

        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>

          <li>
            <Link to="/courses">Courses</Link>
          </li>

          <li>
            <Link to="/profile">Profile</Link>
          </li>
        </ul>

        <p>
          Enrolled: <strong>{enrolledCourses.length}</strong>
        </p>
      </nav>
    </header>
  );
}

export default Header;
