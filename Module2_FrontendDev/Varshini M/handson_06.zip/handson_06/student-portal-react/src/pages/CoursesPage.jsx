import { Link, useNavigate } from "react-router-dom";

import { useDispatch } from "react-redux";

import { enroll } from "../redux/enrollmentSlice";

import { courses } from "../data/courses";

function CoursesPage() {
  const dispatch = useDispatch();

  const navigate = useNavigate();

  function handleEnroll(course) {
    dispatch(enroll(course));

    navigate("/profile");
  }

  return (
    <div className="container">
      <h1>Courses</h1>

      <div className="course-grid">
        {courses.map((course) => (
          <div className="course-card" key={course.id}>
            <h2>{course.name}</h2>

            <p>{course.code}</p>

            <p>Credits: {course.credits}</p>

            <Link to={`/courses/${course.id}`}>View Details</Link>

            <br />
            <br />

            <button onClick={() => handleEnroll(course)}>Enroll</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default CoursesPage;
