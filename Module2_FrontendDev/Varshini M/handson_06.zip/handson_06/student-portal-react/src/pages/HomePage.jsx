function HomePage() {
  return (
    <div className="container">
      <h1>Welcome to the Student Portal</h1>

      <p>Manage your courses, view your profile, and enroll in new subjects.</p>
    </div>
  );
}

export default HomePage;
