import { useDispatch, useSelector } from "react-redux";

import { unenroll } from "../redux/enrollmentSlice";

function ProfilePage() {
  const dispatch = useDispatch();

  const enrolledCourses = useSelector(
    (state) => state.enrollment.enrolledCourses,
  );

  return (
    <div className="container">
      <h1>My Enrolled Courses</h1>

      {enrolledCourses.length === 0 ? (
        <p>No courses enrolled.</p>
      ) : (
        enrolledCourses.map((course) => (
          <div className="course-card" key={course.id}>
            <h2>{course.name}</h2>

            <p>{course.code}</p>

            <button onClick={() => dispatch(unenroll(course.id))}>
              Remove
            </button>
          </div>
        ))
      )}
    </div>
  );
}

export default ProfilePage;
