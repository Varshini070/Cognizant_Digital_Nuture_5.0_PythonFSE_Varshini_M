import { createContext, useState } from "react";

export const EnrollmentContext = createContext();

export function EnrollmentProvider({ children }) {
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  function enroll(course) {
    const exists = enrolledCourses.find((c) => c.id === course.id);

    if (!exists) {
      setEnrolledCourses([...enrolledCourses, course]);
    }
  }

  function unenroll(courseId) {
    setEnrolledCourses(
      enrolledCourses.filter((course) => course.id !== courseId),
    );
  }

  return (
    <EnrollmentContext.Provider
      value={{
        enrolledCourses,
        enroll,
        unenroll,
      }}
    >
      {children}
    </EnrollmentContext.Provider>
  );
}
