function Header(props) {
  return (
    <header>
      <nav className="container">
        <h1>{props.siteName}</h1>

        <ul>
          <li>
            <a href="#">Home</a>
          </li>

          <li>
            <a href="#">Courses</a>
          </li>

          <li>
            <a href="#">Profile</a>
          </li>
        </ul>

        <p>
          Enrolled Courses: <strong>{props.enrolledCount}</strong>
        </p>
      </nav>
    </header>
  );
}

export default Header;
