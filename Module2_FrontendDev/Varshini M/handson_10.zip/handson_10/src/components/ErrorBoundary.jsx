import { Component } from 'react';

export default class ErrorBoundary extends Component {
  state = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error('Unhandled application error:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return <main className="fallback"><h1>We hit an unexpected problem.</h1><p>Please refresh the page and try again.</p></main>;
    }
    return this.props.children;
  }
}
