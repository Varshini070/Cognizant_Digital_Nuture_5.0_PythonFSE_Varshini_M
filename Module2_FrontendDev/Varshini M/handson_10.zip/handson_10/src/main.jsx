import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Provider } from 'react-redux';
import App from './App';
import ErrorBoundary from './components/ErrorBoundary';
import { store } from './store/store';
import './styles.css';

createRoot(document.getElementById('root')).render(
  <StrictMode><ErrorBoundary><Provider store={store}><App /></Provider></ErrorBoundary></StrictMode>
);
