import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { enrollStudent, getAllCourses } from '../api/courseApi';

export const fetchAllCourses = createAsyncThunk('courses/fetchAll', async () => {
  return await getAllCourses();
});

export const enrollInCourse = createAsyncThunk(
  'courses/enroll',
  async (courseId) => {
    await enrollStudent('student-101', courseId);
    return courseId;
  }
);

const coursesSlice = createSlice({
  name: 'courses',
  initialState: { courses: [], loading: false, enrollingId: null, enrolledIds: [], error: null },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllCourses.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllCourses.fulfilled, (state, action) => {
        state.loading = false;
        state.courses = action.payload;
      })
      .addCase(fetchAllCourses.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Unable to load courses.';
      })
      .addCase(enrollInCourse.pending, (state, action) => {
        state.enrollingId = action.meta.arg;
        state.error = null;
      })
      .addCase(enrollInCourse.fulfilled, (state, action) => {
        state.enrollingId = null;
        state.enrolledIds.push(action.payload);
      })
      .addCase(enrollInCourse.rejected, (state, action) => {
        state.enrollingId = null;
        state.error = action.error.message || 'Enrollment failed.';
      });
  },
});

// Components use selectors instead of knowing the store's internal shape.
export const selectCourses = (state) => state.courses.courses;
export const selectCoursesLoading = (state) => state.courses.loading;
export const selectCoursesError = (state) => state.courses.error;
export const selectEnrollingId = (state) => state.courses.enrollingId;
export const selectEnrolledIds = (state) => state.courses.enrolledIds;

export default coursesSlice.reducer;
