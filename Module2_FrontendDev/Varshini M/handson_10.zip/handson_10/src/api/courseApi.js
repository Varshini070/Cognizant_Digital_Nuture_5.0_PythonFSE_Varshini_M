import apiClient from './apiClient';

// DummyJSON supplies the demo catalogue; this mapper keeps UI code independent of that API's shape.
const toCourse = (product) => ({
  id: product.id,
  title: product.title,
  description: product.description,
  instructor: product.brand || 'CourseHub Faculty',
  level: product.category,
  rating: product.rating,
  image: product.thumbnail,
});

export async function getAllCourses() {
  const data = await apiClient.get('/products?limit=12');
  return data.products.map(toCourse);
}

export async function getCourseById(id) {
  const data = await apiClient.get(`/products/${id}`);
  return toCourse(data);
}

export async function enrollStudent(studentId, courseId) {
  return apiClient.post('/posts/add', { studentId, courseId, action: 'enroll' });
}
