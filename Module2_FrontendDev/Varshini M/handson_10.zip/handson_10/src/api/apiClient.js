import axios from 'axios';

// One configured HTTP client is shared by every API module in the application.
const apiClient = axios.create({
  baseURL: 'https://dummyjson.com',
  headers: { 'Content-Type': 'application/json' },
  timeout: 8000,
});

apiClient.interceptors.request.use((config) => {
  config.headers.Authorization = 'Bearer mock-coursehub-token-2026';
  return config;
});

apiClient.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const standardError = new Error(
      error.response?.data?.message || error.message || 'Something went wrong while contacting the server.'
    );
    standardError.statusCode = error.response?.status || 0;
    return Promise.reject(standardError);
  }
);

export default apiClient;
