import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  enrollInCourse,
  fetchAllCourses,
  selectCourses,
  selectCoursesError,
  selectCoursesLoading,
  selectEnrolledIds,
  selectEnrollingId,
} from '../store/coursesSlice';

export default function CoursesPage() {
  const dispatch = useDispatch();
  const courses = useSelector(selectCourses);
  const loading = useSelector(selectCoursesLoading);
  const error = useSelector(selectCoursesError);
  const enrollingId = useSelector(selectEnrollingId);
  const enrolledIds = useSelector(selectEnrolledIds);

  useEffect(() => { dispatch(fetchAllCourses()); }, [dispatch]);

  return (
    <main>
      <header><span className="eyebrow">Hands-on 10 · Redux Toolkit</span><h1>Find your next course</h1><p>A centralised API layer keeps components focused on the experience.</p></header>
      {error && <div className="error" role="alert">{error} <button onClick={() => dispatch(fetchAllCourses())}>Try again</button></div>}
      {loading ? <p className="status">Loading courses…</p> : (
        <section className="grid" aria-label="Courses">
          {courses.map((course) => {
            const enrolled = enrolledIds.includes(course.id);
            const busy = enrollingId === course.id;
            return <article className="card" key={course.id}>
              <img src={course.image} alt="" />
              <div className="card-content"><span className="tag">{course.level}</span><h2>{course.title}</h2><p>{course.description}</p><small>{course.instructor} · ★ {course.rating}</small>
              <button disabled={enrolled || busy} onClick={() => dispatch(enrollInCourse(course.id))}>{enrolled ? 'Enrolled' : busy ? 'Enrolling…' : 'Enroll now'}</button></div>
            </article>;
          })}
        </section>
      )}
    </main>
  );
}
