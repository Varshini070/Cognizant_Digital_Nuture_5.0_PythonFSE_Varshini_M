# Hands-on 10 — Centralised API & State Management

Implemented with **React + Redux Toolkit**.

## Run

```bash
npm install
npm run dev
```

`src/api/apiClient.js` owns the Axios base URL, timeout, default JSON header, mock authorization token, and response/error interceptors. `courseApi.js` is the only place that makes course-related requests. Components never call Axios directly.

`fetchAllCourses` demonstrates the Redux Toolkit lifecycle: pending sets loading, fulfilled saves courses, and rejected exposes an error message. To test rejection handling, temporarily change `baseURL` in `apiClient.js` to `https://dummyjson.com/invalid`; the error panel will appear.

## State-management comparison

| Framework | Pattern | Trade-off |
| --- | --- | --- |
| React + Redux Toolkit | Slice, thunk, selectors, and a central store. | RTK reduces classic Redux boilerplate; very flexible but requires choosing its tooling. |
| Angular + NgRx | Actions, reducers, selectors, and effects in Angular's DI ecosystem. | Highly structured and powerful tooling, but usually the steepest learning curve and most ceremony. Data flow: Component → dispatch Action → Effect → API → Reducer → State → Selector → Component. |
| Vue + Pinia | Stores expose reactive state, getters, and actions directly. | Least boilerplate and feels natural with Vue reactivity; excellent devtools and a gentler learning curve. |

The app is wrapped in `ErrorBoundary`, which logs unhandled rendering errors and displays a fallback UI.
